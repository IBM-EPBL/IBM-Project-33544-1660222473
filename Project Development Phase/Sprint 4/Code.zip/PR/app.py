#imports

import pyrebase
import streamlit as st
from datetime import datetime
import joblib
import pandas as pd
from collections.abc import Mapping
#from streamlit.script_run_context import add_script_run_ctx
from email_validator import validate_email, EmailNotValidError

#configuration key

firebaseConfig = {
    'apiKey': "AIzaSyBW9IPsQGqk9qrXsgyL8TZpnQ4MacWgc70",
    'authDomain': "test-firestore-streamlit-13160.firebaseapp.com",
    'projectId': "test-firestore-streamlit-13160",
    'databaseURL': "https://console.firebase.google.com/u/0/project/test-firestore-streamlit-13160/database/test-firestore-streamlit-13160-default-rtdb/data/~2F",
    'storageBucket': "test-firestore-streamlit-13160.appspot.com",
    'messagingSenderId': "703800935011",
    'appId': "1:703800935011:web:60fd49fa5c4d09eb002e56",
    'measurementId': "G-GR57GQVJC3"
  }

#firebase authentication

#st.script_run_context.add_script_run_ctx(thread) 
firebase = pyrebase.initialize_app(firebaseConfig)
auth = firebase.auth()

#database

db = firebase.database()
storage = firebase.storage()

st.sidebar.title("Heart Disease Prediction")

#authentication
choice = st.sidebar.selectbox('login/Signup', ['Login', 'Sign up'])

email = st.sidebar.text_input("Please enter your email address")
password = st.sidebar.text_input("Please enter your password")


if choice == 'Sign up':
    handle = st.sidebar.text_input("Please input your username", value = 'Default')
    submit = st.sidebar.button("Create my Account")

    if submit:
        try:
            if email=='' or password=='':
                st.error("Please fill the empty email or password")
            else:
                
                try:                
                    validation = validate_email(email)        
                    user = auth.create_user_with_email_and_password(email, password)
                    st.success("Your account is created successfully")
                    st.balloons()
                    st.title("Welcome "+handle+" !!")
                    st.header("Login to view dashboard")
                except EmailNotValidError as e:
                    st.error("enter valid email")

        except:
            st.error("email already exists")
        
if choice == 'Login':
    login = st.sidebar.button('Login')
    if login:
        try:
            user = auth.sign_in_with_email_and_password(email,password)
        

            st.write('<style>div.row-widget.stRadio > div{flex-direction:row;}</style>', unsafe_allow_html=True)
        
            st.title("Heart Disease Prediction")
            col1, col2, col3 = st.columns(3)
            Age = col1.number_input("Enter your age")

            chest_pain_type = col2.selectbox("Enter chest pain type?",["1","2","3","4"])

            BP = col3.number_input("Enter BP level")

            chol = col1.number_input("Enter cholestrol level")

            maxhr = col2.number_input("Enter max heartrate")

            exe_angina = col3.selectbox("Do you have exercise angina?",["Yes", "No"])

            ST_depr = col1.number_input("Enter ST depression value")

            ST_slope = col2.selectbox("Enter ST slope value",["1","2","3"])

            no_of_vess = col3.selectbox("No of vessels of fluro",["0","1","2","3"])

            thall = col2.number_input("Enter thallium level")

            #st.button('Predict')


            model = joblib.load('hdp_model.pkl')

            df_pred = pd.DataFrame([[Age,chest_pain_type,BP,chol,maxhr,exe_angina,ST_depr,ST_slope,no_of_vess,thall]],columns= ['Age','Chest pain type','BP','Cholesterol','Max HR','Exercise angina','ST depression','Slope of ST','Number of vessels fluro','Thallium'])

            df_pred['Exercise angina'] = df_pred['Exercise angina'].apply(lambda x: 1 if x == 'Yes' else 0)
                

            model = joblib.load('hdp_model.pkl')
            prediction = model.predict(df_pred)

            if st.button('Predict', key = 0):
                if (df_pred['Age']>=120).bool() | (df_pred['Age']<1).bool()  | (df_pred['Cholesterol']<20).bool() | (df_pred['Cholesterol']>600).bool() | (df_pred['BP']>150).bool() | (df_pred['BP']<40).bool() | (df_pred['Max HR']>450).bool() | (df_pred['Max HR']<=0).bool() | (df_pred['Thallium']>8).bool() | (df_pred['Thallium']<0 ).bool() | (df_pred['ST depression']>6).bool() | (df_pred['ST depression']<0).bool():
                    if (df_pred['Age']>=120).bool() | (df_pred['Age']<1).bool():
                        st.write('<p class="big-font">Invalid AGE.. Please fill in appropriate data.</p>',unsafe_allow_html=True) 
                    if (df_pred['Cholesterol']<20).bool() | (df_pred['Cholesterol']>600).bool():
                        st.write('<p class="big-font">Extremely low or high cholestrol level.. Please fill in appropriate data.</p>',unsafe_allow_html=True)
                    if (df_pred['BP']>150).bool() or (df_pred['BP']<40).bool():
                        st.write('<p class="big-font">Not a valid BP level...Please fill in appropriate data.</p>',unsafe_allow_html=True)
                    if (df_pred['Max HR']>2000).bool() | (df_pred['Max HR']<=0).bool():
                        st.write('<p class="big-font">Invalid max heartrate.. Please fill in appropriate data.</p>',unsafe_allow_html=True)
                    if (df_pred['Thallium']>7).bool() | (df_pred['Thallium']<0).bool():
                        st.write('<p class="big-font">Invalid Thallium value.. Please fill in appropriate data.</p>',unsafe_allow_html=True)
                    if (df_pred['ST depression']>6).bool() | (df_pred['ST depression']<0).bool():
                        st.write('<p class="big-font">Invalid ST depression value.. Please fill in appropriate data.</p>',unsafe_allow_html=True)
                elif(prediction[0]=='Absence'):
                    st.write('<p class="big-font">Result, Heart Disease Absent</p>',unsafe_allow_html=True)
                else:
                    st.write('<p class="big-font">Result, Heart Disease Present</p>',unsafe_allow_html=True)
        
        except:
            st.error("incorrect email/password")